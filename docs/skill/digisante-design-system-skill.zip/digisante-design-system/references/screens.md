# Registre des écrans DigiSanté Mobile — Design v2 « Wax & Terre »

Prototypes HTML sources (Tailwind CDN, 390×844) :
- `DigiSante_DesignV2_Lot1_AdminDesktop.html` — D-01→D-08 + Desktop Dashboard
- `DigiSante_DesignV2_Lot2.html` — D-09→D-13
- `DigiSante_DesignV2_Lot3.html` — D-14→D-19
- `DigiSante_DesignV2_Lot4.html` — D-20→D-26 + Desktop KYC Review + Desktop Traductions
- `DigiSante_DesignV2_AdminDesktop_LotFinal.html` — Desktop Utilisateurs + Paiements FedaPay + Audit logs + Éducation santé (CMS)

## Espace PATIENT (vert sante-600, accent terre-500)

| ID | Écran | Spécificités v2 |
|---|---|---|
| D-01 | Onboarding langues | Fond sante-950→800 + bogolan, logo terre `rotate-3` + `stitch-light`, 5 langues en `card-pagne` (FR actif crème), salutation triple « Kú dó gbɛ̀ · Ẹ káàbọ̀ · Bienvenue », kente-bar en haut d'écran |
| D-02 | OTP | Fond `wax-light`, cases OTP `card-pagne` border sante-600, curseur terre pulsant, bouton « appel vocal (Fɔ̀ngbè dispo) », encart chiffrement AES-256 |
| D-03 | Dashboard patient | Header bogolan sante-900 fermé kenté, « Kú dó gbɛ̀ 👋 », pill `FR ▾`, carte RDV flottante `-mt-10` `.stitch`, 4 actions en patchs pivotés ±1°, SOS `pulse-sos`, FAB terre `rotate-3` |
| D-04 | DMP | Carte urgence = pagne sante-900 + kenté + QR crème `rotate-2`, compteurs en patchs pivotés, timeline avec barres latérales (indigo=analyse, vert=consult, ocre=vaccin) |
| D-05 | Recherche médecin | Recherche bordure noire + ombre dure, fiches médecins : avatar bogolan `rotate-2`, badge ✓ VÉRIFIÉ vert, **langues parlées 🗣**, prix FCFA, créneaux en grille (actif terre, passé barré) |
| D-06 | Téléconsultation | Fond nuit + bogolan op .6, zone vidéo indigo `card-pagne stitch-light` + wax-dark, PiP bordure ocre, bouton raccrocher SOS `rotate-3`, note « bascule chat auto si réseau faible » |
| D-07 | SOS | **Bouton octogonal** `.sos-octogone` + `pulse-sos`, position GPS, contact (SMS Twilio **en Fɔ̀ngbè**), 112 SAMU + hôpital proche, carte QR urgence bogolan en pied |
| D-08 | Ordonnance + paiement | Ticket ordonnance : header bogolan + kenté + QR `rotate-2`, lignes à barre latérale (ocre=attente, vert=délivré), séparateur dashed, 3 moyens : MTN MoMo (actif, ombre verte), Moov, **Wallet Diaspora** (« Rechargé par Tonton Pierre 🇫🇷 »), CTA FedaPay terre |
| D-09 | Rappels | « Semaine tissée » : barres card-pagne sur bogolan (92% ocre), carte Maintenant `stitch` + ombre `5px 5px 0`, boutons « ✓ J'ai pris » / « +30 min », SMS fallback **dans la langue** |
| D-10 | Chat faible connexion | Banner ocre, médecin salue en fon, bulles patient coin inversé, partage tension = étoffe cousue 3 mesures, message offline bordure pointillée « En attente d'envoi… », typing dots |
| D-11 | Résultats labo | Interprétation cousue + **« 🔊 Écouter en Fɔ̀ngbè (audio 0:42) »**, jauges card-pagne avec repère réf., Triglycérides bordure ocre + tendance |
| D-12 | Profil & paramètres | Header bogolan + kenté, badge Premium ocre, pills 5 langues, sections préfixées nkyinkyim, partages actifs avec expiration, export FHIR/PDF Loi N°2017-20 |
| D-13 | Mode hors-ligne | Fond `wax-ocre`, bannière ocre + `.trame-tissee`, grille dispo offline en patchs verts pivotés, file de sync 3 items (horloge ocre), zone « nécessite connexion », **« SOS reste actif — SMS dans votre langue »** |
| D-26 | Éducation santé | Vedette paludisme : pagne vert + kenté + moustiquaire SVG + badge **Audio Fɔ̀ngbè**, chips FR/FON/YO/BA/DE par article, « ★ Recommandé pour vous » terre |

## Espace MÉDECIN PRO (indigo-600, badge PRO terre/ocre)

| ID | Écran | Spécificités v2 |
|---|---|---|
| D-14 | Dashboard médecin | Header bogolan indigo-900 + kenté, avatar ocre badge PRO terre, stats 3 col `.stitch`, file live (badge Live indigo), patient en cours `pulse-live` bordure indigo + ombre dure, **langue du patient 🗣 sur chaque entrée**, triage terre, référencement barre indigo |
| D-15 | Agenda | Jour actif bloc indigo ombre `3px 3px 0`, timeline bandes card-pagne : vert/indigo/pointillés/crème/ocre/rouge(garde récurrente), sélecteur durée 20/30/45 (actif relief) |
| D-16 | Vue 360° patient | Bandeau pagne indigo cousu + kenté, badges O+/⚠Pénicilline/HTA, **tension offline remonte bordée ocre « (offline) »**, traitements barres latérales par observance, accès consenti + expiration + audit APDP |
| D-17 | Prescription | Alerte allergie `stitch-sos` bloquante, recherche ombre dure noire, autocomplete DCI + « Dispo Bénin », cases poso/moment/durée patchs crème, note remplacement ocre, check interactions vert, signature indigo N° Ordre CNOM |
| D-18 | Stats & revenus | Carte revenus pagne indigo (142 500 F, +18%, commission 3%, MTN MoMo), bar-chart card-pagne dégradé indigo, abonnement PRO 15 000 F bordure ocre + ruban coin « Plan actuel », export CSV |
| D-19 | KYC pro | Progression **tissée** `.fill-tisse-indigo`, 3 états : vérifié (patch vert pivoté) / review (patch ocre spinner) / upload (pointillés indigo), info 48h ouvrées, submit désactivé si incomplet |

## Espace DIASPORA / PHARMACIE / LABO (or ocre)

| ID | Écran | Spécificités v2 |
|---|---|---|
| D-20 | Dashboard diaspora | Header gradient or + bogolan + kenté, double horloge Paris/Cotonou, wallet flottant `.stitch`, cartes famille avec **langue du proche** (🗣 Fon, 🗣 Baatɔnum), liseré tissé or, notification paiement à distance |
| D-21 | Wallet | Carte = pagne or bogolan cousu + kenté + nkyinkyim, solde FCFA + **conversion € temps réel**, montants en patchs pivotés, Visa FedaPay International 3-D Secure (frais 1%), historique ± |
| D-22 | Pharmacie scan | Fond nuit bogolan, viseur card-pagne cousu coins **ocre** + scan-line ocre, QR `rotate-2`, vérif crème + kenté « Ordonnance authentique », ligne délivrée barrée traçée, **suggestion générique (−2 400 F)**, CTA délivrance vert |
| D-23 | Labo saisie | Avatar bogolan, champ Troponine `border-2 sos` + ombre, bannière **valeur critique → alerte prescripteur**, PDF upload, « patient notifié **dans sa langue** », Publier+Alerter rouge |

## ADMIN (indigo nuit + actions terre)

| ID | Écran | Spécificités v2 |
|---|---|---|
| D-24 | Admin mobile métriques | Fond indigo-900 bogolan, 4 KPI patchs cousus (3 482 users, 127/j, 4,2M FedaPay, uptime 99,96% p95 142ms PM2×2), dossier KYC prioritaire patch terre + chips docs, alertes (webhooks retry, pg_dump ✓, SSL J-32) |
| D-25 | Admin users & audit | Filtres terre, fraudeur `stitch-sos` SUSPENDU, **audit trail registre** : tags mono KYC_APPROVE/DMP_ACCESS/USER_SUSPEND/PAYMENT_REFUND + IP + horodatage, Loi N°2017-20, export CSV chiffré |
| DESKTOP-1 | Dashboard | Sidebar 270px indigo bogolan + kenté + carte admin, nav active = fond terre/.18 + barre 3px, topbar ⌘K + FR ▾, KPI dont **« Langue #1 : Fɔ̀ngbè 41% »**, table KYC ligne prioritaire, panneau santé VPS (Fastify PM2×2, PostgreSQL 38/200, Redis, backup, SSL), graphe usage langues |
| DESKTOP-2 | KYC Review | Fiche identité + **contre-vérif CNOM « MATCH ✓ »** en pagne indigo, grille 3 docs (RCP ocre à vérifier), checklist 6 pts, note interne obligatoire si rejet, 3 boutons Approuver/Complément/Rejeter, audit journalisé |
| DESKTOP-3 | Traductions | Couverture 5 langues en patchs (FR 100 → Fɔ̀ngbè 97 → Dendi 74%) + compteurs audios, table clés i18n avec traductions fon réelles, états VALIDÉ/À RELIRE/Manquant, **clés critiques (sos.*, labo.*, payments.*) = double validation locuteur natif** |
| DESKTOP-4 | Utilisateurs | Filtres rôle (Patients/Médecins/Pharmacies/Diaspora) + **filtre langue**, table avec IFU pharmacies, diaspora lié au wallet, fraudeur SUSPENDU fond rouge .05, pagination card-pagne, **panneau détail** (partage DMP actif, lien wallet diaspora↔patient, actions admin), règle : **l'admin ne peut PAS lire le contenu médical du DMP** (chiffré, soignants consentis uniquement) |
| DESKTOP-5 | Paiements FedaPay | 4 KPI (volume, **commissions 3% = revenu plateforme**, reversements pros J+2 MoMo, webhooks échec bordé ocre), table txn 5 statuts (RÉUSSI/WEBHOOK RETRY x/5/REMBOURSÉ/ÉCHEC), filtres par moyen aux couleurs opérateurs (MTN #FFCC00, Moov #0066B3), répartition par moyen (**wallet diaspora 13% — argument NEXT IMPACT**), panneau webhooks (HMAC ✓, DLQ, réconciliation cron 02:30) |
| DESKTOP-6 | Audit logs | Filtres familles (DMP_*, KYC_*, PAYMENT_*, AUTH_*), entrées avec **hash SHA-256 chaîné** + IP + n° séquence, cas types : DMP_DENIED (sans consentement), AUTH_FAIL ×5 (verrouillage 30 min), DATA_EXPORT (portabilité), LAB_CRITICAL (accusé prescripteur), synthèse 24h en patchs pivotés, panneau **Garanties d'intégrité** (append-only PostgreSQL + trigger anti UPDATE/DELETE, rétention 5 ans, réquisition APDP), export CSV chiffré AES-256 |
| DESKTOP-7 | Éducation santé (CMS) | Workflow **Brouillon → Relecture médicale → Traductions → Publié**, table : validateur médecin ✓ affiché, **matrice 5 langues par article** (FON⏳ en cours, DE✗ manquant → « PUBLIÉ PARTIEL »), compteur audio + durée, vues, 3 règles en cartes : validation médicale obligatoire / publication par langue (FR+Fɔ̀ngbè minimum) / **audio Fɔ̀ngbè = ×3 complétion** |

## Continuité de parcours à préserver
- La tension 15,1/9,2 saisie offline (D-13) → file de sync → partagée en chat (D-10) → visible côté médecin bordée ocre (D-16).
- L'ordonnance ORD-2026-08134 émise (D-17) → patient (D-08) → scannée pharmacie (D-22) → ligne « déjà délivré » synchronisée.
- Le wallet rechargé par Pierre (D-21) → moyen de paiement d'Aïcha (D-08) → notification diaspora (D-20).
