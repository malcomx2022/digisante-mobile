---
name: digisante-design-system
description: "Use this skill when applying the DigiSanté Mobile « Wax & Terre » design system to any UI component, page, or screen. Triggers: any mention of 'design DigiSanté', 'Wax & Terre', 'thème DigiSanté', 'motifs africains DigiSanté', 'écran D-01' through 'D-26', or when creating/modifying any visual element of the DigiSanté Mobile PWA (patient, médecin PRO, diaspora, pharmacie, labo, admin). Covers Tailwind tokens, African pattern classes (bogolan, wax, kenté, nkyinkyim, card-pagne, stitch), per-space themes, multilingual UI rules, and PWA responsive rules."
---

# DigiSanté Mobile — Design System v2 « Wax & Terre »

## Brand Identity

**Produit** : DigiSanté Mobile — PWA e-santé, République du Bénin (programme NEXT IMPACT / FP2E / Sèmè City / Banque Mondiale)
**Concept** : motifs textiles africains (bogolan, wax, kenté, adinkra) rendus en **pur CSS/SVG inline — ZÉRO image bitmap**. Identité « fait main » : coins coupés, coutures pointillées, rotations légères, ombres dures.
**Stack cible** : Next.js 14 + Tailwind CSS. Compatible 2G/3G (motifs en data-URI < 1 Ko), offline-first via service worker.
**Logo** : cœur + ligne de pouls dans un carré pagne terre cuite pivoté (`rotate-3`), SVG inline uniquement.

## Color Tokens (tailwind.config.ts)

```typescript
extend: {
  colors: {
    // Vert forêt réchauffé — espace PATIENT (primaire produit)
    sante: {
      50:'#EFF8F1', 100:'#D8EEDD', 200:'#AEDCB9', 300:'#7CC48F',
      400:'#47A562', 500:'#2E8B4F', 600:'#1F7040', // PRIMAIRE patient
      700:'#1A5A36', 800:'#15462B', 900:'#0E3120', // headers bogolan
      950:'#082016',
    },
    // Terre cuite — accent artisanal, CTA transverses
    terre: {
      50:'#FBF1EC', 100:'#F5DCD0', 200:'#EAB9A1', 300:'#DD9270',
      400:'#CF6F45', 500:'#C2542B', // CTA / FAB / badges PRO
      600:'#A84421', 700:'#86361B',
    },
    // Indigo wax — espace MÉDECIN PRO + ADMIN
    indigo: {
      50:'#EEF1F8', 100:'#D8DEED', 200:'#B0BDDB', 300:'#8399C4',
      400:'#5C76A8', 500:'#3F578A', 600:'#2B3A67', // PRIMAIRE PRO
      700:'#223055', 800:'#1A2440', 900:'#121A2E', // sidebar/headers admin
      950:'#0C1220',
    },
    // Or kola — espace DIASPORA, badges premium, motif nkyinkyim
    ocre: {
      50:'#FBF5E4', 100:'#F5E7BE', 200:'#EAD088', 300:'#DDB75A',
      400:'#D4A843', // accent or
      500:'#B8891A', 600:'#94690F', 900:'#4A3A0E',
    },
    sos: { 50:'#FDF1EF', 100:'#F9DCD7', 500:'#D64533', 600:'#B93A2B', 700:'#962F23' },
    creme: { DEFAULT:'#FAF6F0', deep:'#F3ECE1' }, // fond app (JAMAIS gray-50)
    nuit:  { DEFAULT:'#211C16', soft:'#2C261E' }, // écrans sombres (scanner, vidéo)
  }
}
```

## Per-Space Themes (règle absolue)

| Espace | Écrans | Primaire | Header/fond sombre | Accent |
|---|---|---|---|---|
| Patient | D-01→D-13, D-26 | `sante-600` | `sante-900` + `.bogolan-dark` | `terre-500` (CTA/FAB) |
| Médecin PRO | D-14→D-19 | `indigo-600` | `indigo-900` + `.bogolan-dark` | `ocre-400` (badge PRO) |
| Diaspora/Pharma/Labo | D-20→D-23 | gradient or `#4A3A0E→#B8891A` | `.bogolan-dark` sur or | `sante-600` (validations) |
| Admin (mobile+desktop) | D-24, D-25, desktop | `terre-500` (actions) | `indigo-900→indigo-950` + `.bogolan-dark` | `ocre-400` |
| Hors-ligne | D-13 | fond `.wax-ocre` | bannière `ocre-400` trame | — |
| Urgence/SOS | D-07 | `sos-500/600` | bouton octogonal clip-path | — |

## Typography

```typescript
fontFamily: {
  display: ['"Bricolage Grotesque"', 'sans-serif'], // Titres, boutons, stats, badges
  body: ['"DM Sans"', 'sans-serif'],                // Texte courant, inputs
}
```

```html
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,700;12..96,800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
```

⚠️ JAMAIS Sora (réservé ANaTT). Bricolage Grotesque apporte la chasse irrégulière « éditoriale » qui casse l'effet IA.
Poids : titres `font-extrabold`, labels/CTA `font-bold` ou `font-extrabold`, jamais `font-medium` sur du display.

## African Pattern Classes

Le CSS complet (data-URI encodés) est dans `references/patterns.css` — **toujours copier depuis ce fichier**, ne jamais ré-encoder à la main (les `%23` et opacités sont calibrés).

| Classe | Usage | Règle |
|---|---|---|
| `.bogolan-dark` | zigzags mudcloth blancs op .09 | sur TOUS les fonds sombres (sante-900, indigo-900, or, nuit) |
| `.bogolan-light` | zigzags terre op .07 | fonds clairs ponctuels |
| `.wax-light` | cercles concentriques verts op .06 | fond de page patient/PRO (body crème) |
| `.wax-ocre` | cercles or op .08 | fond mode hors-ligne (D-13) |
| `.wax-dark` | cercles blancs op .07 | zones vidéo/scanner sombres |
| `.nkyinkyim` | zigzag adinkra or, repeat-x h-12px | séparateurs (remplace `<hr>`), avant titres de sections |
| `.kente-bar` | frise tissée 6 couleurs h-8px + trame | ferme chaque header sombre, ouvre les cartes héro. Remplace flag-bar |
| `.card-pagne` | clip-path coin coupé 18px | TOUTES les cartes, boutons, avatars, badges, barres de jauges |
| `.stitch` / `.stitch-terre` / `.stitch-light` | couture dashed offset -7px | cartes importantes (1 max par groupe visuel) |

## Signature « fait main » (anti-IA)

1. **Rotations légères** : avatars, icônes carrées, patchs de grilles → alterner `rotate-1`/`-rotate-1`/`rotate-2`/`-rotate-2`. Jamais plus de ±3°.
2. **Ombres dures sérigraphie** : éléments mis en avant → `shadow-[4px_4px_0_rgba(...,.15-.25)]` ou `5px 5px 0`. Couleur de l'ombre = teinte du thème.
3. **Coins coupés partout** : `.card-pagne` par défaut ; bulles de chat utilisateur → coin coupé inversé `clip-path:polygon(18px 0,100% 0,100% 100%,0 100%,0 18px)`.
4. **Soulignés pointillés** : liens texte → `underline decoration-dotted underline-offset-4`.
5. **Bordures séparatrices** : `border-b border-dashed` (tickets, ordonnances) au lieu de solid.
6. Rien n'est parfaitement aligné/symétrique : c'est voulu.

## Component Library

### Boutons
```html
<!-- CTA principal patient (terre cuite) -->
<button class="w-full bg-terre-500 text-white font-display font-extrabold text-[15px] card-pagne py-4 shadow-[0_10px_26px_rgba(194,84,43,.4)]">

<!-- CTA espace PRO (indigo) -->
<button class="bg-indigo-600 text-white font-display font-extrabold card-pagne py-3 shadow-[0_8px_20px_rgba(43,58,103,.35)]">

<!-- Validation santé (vert) -->
<button class="bg-sante-600 text-white font-display font-extrabold card-pagne py-2.5">

<!-- Outline -->
<button class="bg-white border-2 border-indigo-600 text-indigo-600 font-display font-extrabold card-pagne py-3">

<!-- FAB nav centrale : card-pagne + rotate-3 + border-4 border-creme -->
<div class="w-14 h-14 card-pagne bg-terre-500 shadow-[0_10px_24px_rgba(194,84,43,.45)] flex items-center justify-center border-4 border-creme rotate-3">
```

### Carte pagne type
```html
<div class="bg-white card-pagne stitch p-4 border border-stone-200">
  <!-- contenu ; séparateur interne : -->
  <div class="nkyinkyim w-full my-3 opacity-30"></div>
</div>
```

### Header sombre type (patient = sante-900, PRO/admin = indigo-900, diaspora = gradient or)
```html
<div class="bg-sante-900 bogolan-dark relative pb-16">
  <!-- statusbar avec pill langue : -->
  <span class="text-[11px] px-2 py-0.5 rounded-full bg-white/15 border border-white/20 text-white font-bold">FR ▾</span>
  <!-- ... -->
  <div class="absolute bottom-0 left-0 right-0 kente-bar"></div>
</div>
<!-- carte flottante : --> <div class="px-6 -mt-10 relative z-20">…</div>
```

### Badges
```html
<span class="px-2 py-0.5 card-pagne text-[9.5px] font-extrabold bg-sante-50 text-sante-700">NORMAL</span>
<span class="px-2 py-0.5 card-pagne text-[9.5px] font-extrabold bg-ocre-50 text-ocre-600">ÉLEVÉ ▲</span>
<span class="px-2 py-0.5 card-pagne text-[8.5px] font-extrabold bg-ocre-400 text-stone-900">PRIORITÉ</span>
<span class="px-1.5 card-pagne bg-terre-500 text-white text-[7px] font-extrabold py-0.5">PRO</span>
```

### Jauges & graphiques
Barres de progression et bar-charts en `.card-pagne` (jamais rounded-full) ; remplissage tissé possible :
`background:repeating-linear-gradient(90deg,#2B3A67 0 14px,#3F578A 14px 24px)`.

### Toggles
`toggle-on` fond `#1F7040`, `toggle-off` fond `#D6D0C4`, pastille `#FAF6F0` (cf. patterns.css).

## Multilingual Rules (5 langues : FR, Fɔ̀ngbè, Yorùbá, Baatɔnum, Dendi)

1. **Pill langue dans CHAQUE statusbar/topbar** : `FR ▾` (fond `bg-stone-900 text-creme` sur clair, `bg-white/15` sur sombre).
2. Salutations natives dans les headers : « Kú dó gbɛ̀ » (fon), « Ẹ káàbọ̀ » (yoruba).
3. Fiches médecins/patients : afficher les langues parlées `🗣 Fon · Français`.
4. Contenu éducatif : chips langues par article `FR FON YO BA DE` + badge « 🔊 Audio Fɔ̀ngbè dispo » (oralité).
5. SMS critiques (SOS, rappels, labo) : toujours mentionner « dans votre langue ».
6. Sélecteur langue D-12 : pills `.card-pagne`, active = `bg-sante-600 text-white`.
7. Admin : module Traductions = couverture %, audios comptés, clés critiques (sos.*, labo.*, payments.*) à double validation.

## Layout Blueprints

### Mobile PWA (390px base, mobile-first)
```
┌ statusbar 44px (heure + pill langue FR ▾) ─────────────┐
├ header sombre bogolan + kenté en bas ──────────────────┤
├ carte flottante -mt-10 z-20 (.card-pagne .stitch) ─────┤
│ [contenu : fond .wax-light sur crème]                  │
├ bottom-nav 5 items : nkyinkyim au-dessus, FAB centrale ┤
│ card-pagne rotate-3, actif = font-extrabold + couleur  │
└─────────────────────────────────────────────────────────┘
```

### Admin Desktop (≥1280px ; en dessous → layout mobile D-24/D-25)
```
┌ Sidebar 270px (indigo-800→900 + bogolan-dark) ┬ Topbar 64px (blanc) ┐
│ Logo terre rotate-2 | kente-bar               │ titre + ⌘K + FR ▾   │
│ Carte admin (.stitch-light)                   ├─────────────────────┤
│ Nav sectionnée : actif = bg terre/.18         │ Contenu p-7         │
│   + barre gauche terre-400 3px                │ fond .wax-light     │
│ Footer : kente-bar + infos VPS                │ KPI .card-pagne     │
└───────────────────────────────────────────────┴─────────────────────┘
```

## Responsive / PWA Rules

- Mobile-first : classes de base = 390px ; `md:` grilles 2 col (tablette) ; `xl:`/`≥1280px` admin sidebar.
- Motifs = `background-image` CSS data-URI → 0 requête réseau, cachés par le service worker avec le CSS.
- Cibles tactiles ≥ 44px ; FAB 56px.
- Mode hors-ligne (D-13) : fond `.wax-ocre` + bannière `ocre-400` avec trame `repeating-linear-gradient(90deg,transparent 0 10px,rgba(0,0,0,.05) 10px 12px)` — l'état dégradé doit être visible au premier regard.
- `prefers-reduced-motion` : désactiver scan-line, pulse, spin.

## Screen Registry & full patterns

- `references/patterns.css` — CSS complet prêt à copier (motifs, kenté, pagne, coutures, toggles, animations).
- `references/screens.md` — registre D-01 → D-26 + **7 vues admin desktop** (Dashboard, KYC Review, Traductions, Utilisateurs, Paiements FedaPay, Audit logs, Éducation santé), avec spécificités par écran et fichiers prototypes sources.

## Icons

SVG inline uniquement, style Lucide : `stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"`.
Emojis tolérés UNIQUEMENT comme contenu culturel (🇧🇯 🗣 🔊 ★), jamais comme icônes d'interface. Pas d'icon fonts.

## Critical Rules

1. Fond app = `creme` #FAF6F0 — JAMAIS gray-50/white pur en fond de page.
2. `.card-pagne` sur toute carte/bouton/avatar ; `rounded-xl/2xl` interdit sur les conteneurs principaux (réservé aux pills/toggles).
3. Chaque header sombre porte `.bogolan-dark` ET se ferme par `.kente-bar`.
4. `.nkyinkyim` remplace tout `<hr>`/divider plat.
5. 1 seule `.stitch` par groupe visuel (la carte la plus importante).
6. Thème par espace strict : patient vert / PRO indigo / diaspora or / admin indigo+terre. Ne jamais mélanger les primaires.
7. Pill langue présente sur chaque écran ; langues parlées sur chaque fiche personne.
8. Rotations ±1-3° et ombres dures sur les éléments saillants — c'est la signature anti-IA, ne pas « nettoyer ».
9. Bricolage Grotesque pour TOUT le display ; DM Sans pour le corps.
10. SOS : bouton octogonal `clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%)` + `pulse-sos` ; reste actif hors-ligne (fallback SMS Twilio).
